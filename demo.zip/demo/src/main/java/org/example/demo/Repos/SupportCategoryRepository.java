package org.example.demo.Repos;

import org.example.demo.Entities.Role;
import org.example.demo.Entities.SupportServiceCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupportCategoryRepository extends JpaRepository<SupportServiceCategory, Integer> {
}
