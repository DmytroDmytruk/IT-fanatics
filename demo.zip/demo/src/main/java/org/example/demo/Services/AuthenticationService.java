package org.example.demo.Services;

import lombok.RequiredArgsConstructor;
import org.example.demo.DTOs.JwtAuthenticationResponse;
import org.example.demo.DTOs.SignInRequest;
import org.example.demo.DTOs.SignUpRequest;
import org.example.demo.Entities.Role;
import org.example.demo.Entities.RoleEnum;
import org.example.demo.Entities.User;
import org.example.demo.Repos.RoleRepository;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final RoleRepository roleRepository;
    private final UserService userService;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;


    public JwtAuthenticationResponse signUp(SignUpRequest request){
        RoleEnum roleEnum = RoleEnum.getByRoleName(request.getRole());
        Role role = roleRepository.findById(roleEnum.ordinal()).orElseThrow();
        Date utilDate = null;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        try {
            utilDate = dateFormat.parse(request.getBirthDay());
        } catch (Exception e){
            e.printStackTrace();
        }

        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

        var user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .birthDay(sqlDate)
                .phoneNumber(request.getPhone())
                .passportData(request.getPassportData())
                .fullName(request.getFullName())
                .role(role)
                .country(request.getCountry())
                .volunteerTicket(request.getVolunteerTicket())
                .refugeeTicket(request.getRefugeeTicket())
                .soldierTicket(request.getSoldierTicket())
                .build();

        userService.create(user);

        var jwt = jwtService.generateToken(user);
        return new JwtAuthenticationResponse(jwt);
    }


    public JwtAuthenticationResponse signIn(SignInRequest request) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                request.getUsername(),
                request.getPassword()
        ));

        var user = userService
                .userDetailsService()
                .loadUserByUsername(request.getUsername());

        var jwt = jwtService.generateToken(user);
        return new JwtAuthenticationResponse(jwt);
    }
}
