package org.example.demo.Controllers;

import org.example.demo.DTOs.Donation;
import org.example.demo.Services.DonationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/soldier")
public class SoldierController {

    @Autowired
    private DonationService donationService;

    @PostMapping("/add-donations")
    public void addDonation(@RequestBody Donation donation) {
        donationService.addDonation(donation);
    }
}
