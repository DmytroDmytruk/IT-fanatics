package org.example.demo.Repos;

import org.example.demo.Entities.DonationCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonationCategoryRepository extends JpaRepository<DonationCategory, Integer> {
}
