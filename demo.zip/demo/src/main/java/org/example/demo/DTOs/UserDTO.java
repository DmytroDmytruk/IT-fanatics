package org.example.demo.DTOs;


import lombok.*;
import org.example.demo.Entities.Role;

import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDTO {
    private Long userId;
    private String email;
    private String username;
    private String fullName;
    private String phoneNumber;
    private byte[] passportData;
    private byte[] soldierTicket;
    private byte[] volunteerTicket;
    private byte[] refugeeTicket;
    private boolean isVerified;
    private Role role;
    private Date birthDay;
    private String country;
}
