package org.example.demo.Services;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.example.demo.DTOs.UserDTO;
import org.example.demo.Entities.Role;
import org.example.demo.Entities.RoleEnum;
import org.example.demo.Entities.User;
import org.example.demo.Repos.RoleRepository;
import org.example.demo.Repos.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.function.support.RouterFunctionMapping;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository repository;
    private final UserRepository userRepository;
    private final RouterFunctionMapping routerFunctionMapping;
    @Value("${token.signing.key}")
    private String SECRET;
    public User save(User user) {
        return repository.save(user);
    }


    public User create(User user) {
        if (repository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Користувач з таким іменем вже існує");
        }

        if (repository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Користувач з такою поштою вже існує");
        }

        return save(user);
    }


    /*public List<UserDTO> getNotVerifiedUsers(){
        List<User> users = userRepository.findByIsVerifiedFalse();
    }*/


    public User getByUsername(String username) {
        return repository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Користувача не знайдено"));
    }


    public UserDetailsService userDetailsService() {
        return this::getByUsername;
    }


    public UserDTO getCurrentUser(String token) {

        String username = Jwts.parser().setSigningKey(SECRET).parseClaimsJws(token.substring(7)).getBody().getSubject();
        User user = getByUsername(username);
        return UserDTO.builder()
                .email(user.getEmail())
                .username(user.getUsername())
                .phoneNumber(user.getPhoneNumber())
                .role(user.getRole())
                .passportData(user.getPassportData())
                .phoneNumber(user.getPhoneNumber())
                .isVerified(user.isVerified())
                .fullName(user.getFullName())
                .userId(user.getUserId())
                .birthDay(user.getBirthDay())
                .refugeeTicket(user.getRefugeeTicket())
                .soldierTicket(user.getSoldierTicket())
                .volunteerTicket(user.getVolunteerTicket())
                .build();
    }

   /* @Deprecated
    public void setRole() {
        var user = getCurrentUser();
        user.setRole(RoleEnum);
        save(user);
    }


*/

    /*
    @Deprecated
    public void getAdmin() {
        var user = getCurrentUser();
        user.setRole(Role.ROLE_ADMIN);
        save(user);
    }*/
}