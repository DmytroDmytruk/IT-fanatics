package org.example.demo.Entities;

import jakarta.persistence.*;
import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "apartaments")
public class Apartment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "apartaments_id")
    private Long apartmentId;

    @Column(name = "type")
    private String type;

    @Column(name = "address")
    private String address;

    @Column(name = "rooms_count")
    private Integer roomsCount;

    @Column(name = "price")
    private Integer price;

    @Column(name = "people_count")
    private Integer peopleCount;

    @Column(name = "people_count_free")
    private Integer peopleCountFree;
    // Getters and setters
}