package org.example.demo.Controllers;

import org.example.demo.DTOs.UserDTO;
import org.example.demo.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private UserService userService;
/*
    @GetMapping("/get-varification-data")
    public UserDTO getVerificationData() {
        return userService.getCurrentUser();
    }*/
/*
    @PostMapping("/verify")
    public String verify(@RequestBody String userId) {

    }*/
}
