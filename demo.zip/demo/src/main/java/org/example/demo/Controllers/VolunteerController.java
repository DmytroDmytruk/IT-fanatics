package org.example.demo.Controllers;

import org.example.demo.DTOs.Donation;
import org.example.demo.Services.DonationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/volunteer")
public class VolunteerController {
    @Autowired
    private DonationService donationService;

    @GetMapping("/test")
    public String test() {
        return "Hello Volunteer";
    }

    @PostMapping("/add-donation")
    public void addDonation(@RequestBody Donation donation) {
        donationService.addDonation(donation);
    }
}
