package org.example.demo.Entities;

import lombok.*;
import jakarta.persistence.*;

import java.util.Date;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "housing_advertisement")
public class HousingAdvertisement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "housing_advertisement_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "apartament_id")
    private Apartment apartment;

    @Column(name = "adding_date")
    private Date addingDate;

    @Column(name = "is_active")
    private boolean isActive;

    // Getters and setters
}