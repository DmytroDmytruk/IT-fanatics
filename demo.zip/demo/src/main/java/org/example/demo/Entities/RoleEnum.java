package org.example.demo.Entities;

public enum RoleEnum {
    unregistered(0),
    user(1),
    volunteer(2),
    refugee(3),
    soldier(4),
    admin(5);

    private final int roleNumber;

    RoleEnum(int roleNumber) {
        this.roleNumber = roleNumber;
    }

    public int getRoleNumber() {
        return roleNumber;
    }

    public static RoleEnum getByRoleName(String roleName) {
        for (RoleEnum role : RoleEnum.values()) {
            if (role.name().equalsIgnoreCase(roleName)) {
                return role;
            }
        }
        throw new IllegalArgumentException("Invalid RoleEnum name: " + roleName);
    }


    public static RoleEnum getByRoleNumber(int number) {
        for (RoleEnum role : RoleEnum.values()) {
            if (role.getRoleNumber() == number) {
                return role;
            }
        }
        throw new IllegalArgumentException("Invalid RoleEnum number: " + number);
    }
}