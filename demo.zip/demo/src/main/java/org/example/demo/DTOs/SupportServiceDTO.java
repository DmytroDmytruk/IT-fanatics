package org.example.demo.DTOs;

import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SupportServiceDTO {
    private Integer supportServiceId;
    private String supportServiceName;
    private Integer serviceCategoryId;
    private String description;
    private String reference;
}
