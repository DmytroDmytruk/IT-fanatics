package org.example.demo.Services;

import org.example.demo.DTOs.SupportServiceDTO;
import org.example.demo.Entities.SupportService;
import org.example.demo.Entities.SupportServiceCategory;
import org.example.demo.Repos.SupportCategoryRepository;
import org.example.demo.Repos.SupportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SupportionService {
    @Autowired
    SupportRepository supportRepository;
    @Autowired
    SupportCategoryRepository supportCategoryRepository;

    public List<SupportServiceDTO> getSupportListByCategory(int categoryId) {
        SupportServiceCategory category = supportCategoryRepository.findById(categoryId).orElseThrow();
        List<SupportService> data = supportRepository.findAllByCategory(category);
        List<SupportServiceDTO> result = new ArrayList<>();
        for (SupportService service : data) {
            result.add(convertToDto(service));
        }
        return result;
    }


    public List<SupportServiceDTO> getAllSupportServices() {
        List<SupportService> data = supportRepository.findAll();
        List<SupportServiceDTO> result = new ArrayList<>();
        for (SupportService service : data) {
            result.add(convertToDto(service));
        }
        return result;
    }

    public void addSupportService(SupportServiceDTO supportServiceDTO) {
        supportRepository.save(convertToEntity(supportServiceDTO));
    }


    public SupportServiceDTO convertToDto(SupportService supportService) {
        if (supportService == null) {
            return null;
        }

        return SupportServiceDTO.builder()
                .supportServiceId(supportService.getId() != null ? supportService.getId().intValue() : null)
                .supportServiceName(supportService.getServiceName())
                .serviceCategoryId(Math.toIntExact(supportService.getCategory() != null ? supportService.getCategory().getId() : null))
                .description(supportService.getDescription())
                .reference(supportService.getReference() != null ? String.valueOf(supportService.getReference()) : null)
                .build();
    }

    public SupportService convertToEntity(SupportServiceDTO supportServiceDTO) {
        if (supportServiceDTO == null) {
            return null;
        }

        SupportService supportService = new SupportService();
        supportService.setId(supportServiceDTO.getSupportServiceId() != null ? supportServiceDTO.getSupportServiceId().longValue() : null);
        supportService.setServiceName(supportServiceDTO.getSupportServiceName());


        if (supportServiceDTO.getServiceCategoryId() != null) {
            SupportServiceCategory category = new SupportServiceCategory();
            category.setId(supportServiceDTO.getServiceCategoryId().longValue());
            supportService.setCategory(category);
        }
        supportService.setDescription(supportServiceDTO.getDescription());
        supportService.setReference(supportServiceDTO.getReference());
        return supportService;
    }


}
