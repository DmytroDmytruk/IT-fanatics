package org.example.demo.Controllers;


import org.example.demo.DTOs.Donation;
import org.example.demo.Services.DonationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/donation")
public class DonationController {
    @Autowired
    private DonationService donationService;

    @GetMapping("/get-all-donations")
    public List<Donation> getAllDonations() {
        return donationService.getDonationList();
    }

    @PostMapping("/update-donate")
    public void updateDonation(@RequestBody String donationId, @RequestBody String increment) {
        donationService.updateDonation(Long.parseLong(donationId), Float.parseFloat(increment));
    }
}
