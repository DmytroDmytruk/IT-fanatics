package org.example.demo.Controllers;

import org.example.demo.DTOs.SupportServiceDTO;
import org.example.demo.Entities.SupportService;
import org.example.demo.Services.SupportionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/support")
public class SupportServiceController {

    @Autowired
    private SupportionService supportService;

    @GetMapping("/get-by-category")
    public List<SupportServiceDTO> getByCategory(@RequestBody String categoryId) {
        return supportService.getSupportListByCategory(Integer.parseInt(categoryId));
    }

    @GetMapping("/get-all")
    public List<SupportServiceDTO> getAll() {
        return supportService.getAllSupportServices();
    }

    @PostMapping("add-support-service")
    public void addSupportService(@RequestBody SupportServiceDTO supportServiceDTO) {
        supportService.addSupportService(supportServiceDTO);
    }
}
