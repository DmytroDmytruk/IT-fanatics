package org.example.demo.Services;

import lombok.Setter;
import org.example.demo.DTOs.Donation;
import org.example.demo.Entities.DonationsCollection;
import org.example.demo.Entities.User;
import org.example.demo.Repos.DonationCategoryRepository;
import org.example.demo.Repos.DonationsRepository;
import org.example.demo.Repos.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class DonationService {
    @Autowired
    private DonationsRepository donationsRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DonationCategoryRepository donationCategoryRepository;

    public List<Donation> getDonationList(){
        List<DonationsCollection> donationList = donationsRepository.findAll();
        List<Donation> donations = new ArrayList<>();
        for (DonationsCollection donation : donationList){
            donations.add(convertToDto(donation));
        }
        return donations;
    }


    public Donation convertToDto(DonationsCollection donationsCollection) {
        if (donationsCollection == null) {
            return null;
        }

        return Donation.builder()
                .collectionId(donationsCollection.getId() != null ? donationsCollection.getId().intValue() : null)
                .userId(Math.toIntExact(donationsCollection.getUser() != null ? donationsCollection.getUser().getUserId() : null))
                .name(donationsCollection.getName())
                .description(donationsCollection.getDescription())
                .reference(donationsCollection.getReference())
                .goal(donationsCollection.getGoal())
                .currency(donationsCollection.getCurrency())
                .collectedAmount(donationsCollection.getCollectedAmount())
                .photo(donationsCollection.getPhoto())
                .categoryId(donationsCollection.getDonationCategory().getDonationCategoryId())
                .build();
    }

    public DonationsCollection convertToEntity(Donation donation) {
        if (donation == null) {
            return null;
        }

        DonationsCollection donationsCollection = new DonationsCollection();
        donationsCollection.setId(donation.getCollectionId() != null ? donation.getCollectionId().longValue() : null);

        donationsCollection.setUser(userRepository.findById(Long.valueOf(donation.getUserId())).orElseThrow());
        donationsCollection.setName(donation.getName());
        donationsCollection.setDescription(donation.getDescription());
        donationsCollection.setReference(donation.getReference());
        donationsCollection.setGoal(donation.getGoal());
        donationsCollection.setCurrency(donation.getCurrency());
        donationsCollection.setCollectedAmount(donation.getCollectedAmount());
        donationsCollection.setPhoto(donation.getPhoto());
        donationsCollection.setDonationCategory(donationCategoryRepository.findById(donation.getCategoryId()).orElseThrow());

        return donationsCollection;
    }

    public void addDonation(Donation donation) {
        donationsRepository.save(convertToEntity(donation));
    }

    public void updateDonation(Long id, float increment) {
        donationsRepository.updateCollectedAmountById(id, increment);
    }


}
