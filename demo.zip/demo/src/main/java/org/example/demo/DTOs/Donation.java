package org.example.demo.DTOs;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class Donation{
    private Integer collectionId;
    private Integer userId;
    private Integer categoryId;
    private String name;
    private String description;
    private String reference;
    private Float goal;
    private String currency;
    private Float collectedAmount;
    private byte[] photo;
}
